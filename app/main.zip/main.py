import pandas as pd
from pandas import DataFrame
import neo4j # just for testing
from neo4j import GraphDatabase # for data loader
import graphistry
import os
from dotenv import load_dotenv
from fastapi.responses import JSONResponse
from fastapi.encoders import jsonable_encoder
import logging
import json
from fastapi import FastAPI  
from neo4j import GraphDatabase
from neo4j.exceptions import ServiceUnavailable
import numpy as np
import matplotlib.pyplot as plt
from urllib.parse import urlsplit, parse_qs
from fastapi.middleware.cors import CORSMiddleware

# print('neo4j', neo4j.__version__)
# print(dir(graphistry))
# print('graphistry', graphistry.__version__)
DELETE_EXISTING_DATABASE=False
POPULATE_DATABASE=False
load_dotenv()
uri=os.getenv("uri")
user=os.getenv("user")
pwd=os.getenv("pwd")

origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
]


# graphistry.register(api=3, username='jagadeesh_aarth', password='Prat2020')
# graphistry.register(api=3, token=initial_one_hour_token)
graphistry.register(api=3,personal_key_id='UGVFQTFYBQ', personal_key_secret='NHK0S3RKO59EB3H8', protocol='https', server='hub.graphistry.com')
# NEO4J={'uri':"neo4j+s://6bb63f78.databases.neo4j.io", 'auth':("neo4j", "mib9K3dAFRX_wBZ2BxfNY9LA2rzD7hsrRVkO4MpZc1U")}
NEO4J={'uri':uri, 'auth':(user, pwd)}
graphistry.register(bolt=NEO4J)


def connection():
  driver=GraphDatabase.driver(uri=uri,auth=(user,pwd))
  return (driver)
driver_neo4j=connection()
app = FastAPI()  
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
) 
@app.get("/") 
async def main_route():     
  return {"message": "Hey, Graphistry!!"}



@app.get("/runQuery")
def countnode(cypherQuery):
    try:

      q1=cypherQuery

      g = graphistry.cypher(q1)
      shareable_and_embeddable_url=g.plot(render=False)
      query = urlsplit(shareable_and_embeddable_url).query
      print(query)
      params = parse_qs(query)   
      print(params)
      content = {"message": "Hello World"}
      json_compatible_item_data = (params)
      headers = { "Content-Language": "en-US"}
    except ServiceUnavailable as exception:
            logging.error("{query} raised an error: \n {exception}".format(
                query=q1, exception=exception))
            raise
    # return JSONResponse(content=json_compatible_item_data,headers=headers)
    return params['dataset']

